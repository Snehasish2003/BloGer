
import { Route, Routes } from "react-router-dom";
import LoginSignUp from "./components/LoginSignup/loginnsignup";
import HomePage from "./pages/HomePage";
import ProfilePage from "./pages/ProfilePage";
import UserProfilePage from "./pages/UserProfilePage";


const App = () => {
  return (
    <>
   <Routes>
    <Route path="/" element={<LoginSignUp />}></Route>
    <Route path="/home" element={<HomePage />}></Route>
    <Route path="/profile" element={<ProfilePage />}></Route>
    <Route path="/profile/:userId" element={<UserProfilePage />} />
  
   </Routes>
    </>
    
  )
}

export default App
