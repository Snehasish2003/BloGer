// Import the functions you need from the SDKs you need
import { initializeApp } from "firebase/app";
import { getAuth } from "firebase/auth"; 
import { getFirestore } from "firebase/firestore";
import { GoogleAuthProvider } from "firebase/auth";
import { FacebookAuthProvider } from "firebase/auth";
// TODO: Add SDKs for Firebase products that you want to use
// https://firebase.google.com/docs/web/setup#available-libraries
// Your web app's Firebase configuration
const firebaseConfig = {
  apiKey: "AIzaSyCPYTWcuYX7LCeMparM0QIpO5pk-fklMr0",
  authDomain: "blog-f49e7.firebaseapp.com",
  projectId: "blog-f49e7",
  storageBucket: "blog-f49e7.appspot.com",
  messagingSenderId: "306349213630",
  appId: "1:306349213630:web:a62ea16cb572ffa80b1bef"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);


export const auth=getAuth();
export const db = getFirestore(app);
export const googleProvider = new GoogleAuthProvider();
export const facebookProvider = new FacebookAuthProvider();
export default app;