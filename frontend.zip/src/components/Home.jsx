import profile from "../assets/profile.jpg";
import { CircleHelp, SquarePen, Pencil } from 'lucide-react';
import Blog from "./Blog";
import CreatePost from "./smallComponents/CreatePost";
import { useState } from "react";

const Home = () => {
  const [create, setCreate] = useState(false);

  const handleCreate = () => {
    setCreate(true);
  };

  const handleCloseCreate = () => {
    setCreate(false);
  };

  return (
    <div className='w-full flex flex-col items-center mt-16 '>
      <div className="w-full md:w-3/4 lg:w-1/2 bg-[#262626] mt-5 p-4">
        <div className="w-full flex items-center px-5">
          <img src={profile} alt="" className="rounded-full w-10" />
          <div className="w-full bg-[#202020] rounded-3xl p-2 ml-2 cursor-pointer" onClick={handleCreate}>
            <p className="text-[#afb1b3] text-sm ml-2">
              What do you want to ask or share?
            </p>
          </div>
        </div>
        <div className="w-full flex justify-between items-center text-center mt-4">
          <div onClick={handleCreate} className="flex-1 flex justify-center items-center text-white text-sm p-2 gap-2 hover:bg-[#464748] hover:rounded-3xl cursor-pointer">
            <CircleHelp color="white" height={20} width={20} />Ask
          </div>
          <div onClick={handleCreate} className="flex-1 flex justify-center items-center text-white text-sm p-2 gap-2 hover:bg-[#464748] hover:rounded-3xl cursor-pointer">
            <SquarePen color="white" height={20} width={20} />News
          </div>
          <div onClick={handleCreate} className="flex-1 flex justify-center items-center text-white text-sm p-2 gap-2 hover:bg-[#464748] hover:rounded-3xl cursor-pointer">
            <Pencil color="white" height={20} width={20} />Post
          </div>
        </div>
      </div>
      <div className="w-full md:w-3/4 lg:w-1/2">
        <Blog />
      </div>
      <CreatePost selected={create} onClose={handleCloseCreate} />
    </div>
  );
};

export default Home;
