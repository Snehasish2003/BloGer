import React, { useState, useEffect } from 'react';
import { doc, getDoc } from 'firebase/firestore';
import { db } from '../Firebase/firebase';

const Followers = ({ userId, onClose }) => {
  const [followers, setFollowers] = useState([]);
  const [following, setFollowing] = useState([]);
  const [activeTab, setActiveTab] = useState('followers'); // To switch between followers and following

  useEffect(() => {
    const fetchFollowersAndFollowing = async () => {
      const userRef = doc(db, 'users', userId);
      const userDoc = await getDoc(userRef);
      if (userDoc.exists()) {
        const userData = userDoc.data();
        setFollowers(userData.followers || []);
        setFollowing(userData.following || []);
      }
    };

    fetchFollowersAndFollowing();
  }, [userId]);

  return (
    <div className={`absolute w-screen h-screen flex justify-center items-center top-0 left-0 bg-[#363434e6]`}>
      <div className="w-[60%] h-[80%] bg-[#181818] relative p-5 rounded-lg">
        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute top-4 right-4 text-white text-xl font-bold"
        >
          &times;
        </button>
        <div className="flex justify-between items-center border-b border-gray-700 pb-3">
          <button
            className={`text-lg font-bold ${activeTab === 'followers' ? 'text-red-500' : 'text-gray-500'}`}
            onClick={() => setActiveTab('followers')}
          >
            {followers.length} Followers
          </button>
          <button
            className={`text-lg font-bold ${activeTab === 'following' ? 'text-red-500' : 'text-gray-500'}`}
            onClick={() => setActiveTab('following')}
          >
            {following.length} Following
          </button>
        </div>
        <div className="overflow-y-auto mt-4">
          {activeTab === 'followers' ? (
            followers.length > 0 ? (
              followers.map((follower, index) => (
                <div key={index} className="flex items-center justify-between p-3 border-b border-gray-700">
                  <div className="flex items-center">
                    <img src={follower.photoURL || '/path/to/default/image.png'} alt={follower.name} className="w-10 h-10 rounded-full" />
                    <div className="ml-4">
                      <p className="text-white font-semibold">{follower.name}</p>
                      <p className="text-gray-400 text-sm">{follower.description || 'No description'}</p>
                    </div>
                  </div>
                  <button className="text-blue-500 border border-blue-500 rounded-full px-4 py-1">
                    Follow
                  </button>
                </div>
              ))
            ) : (
              <p className="text-gray-500 text-center">No followers yet.</p>
            )
          ) : (
            following.length > 0 ? (
              following.map((follow, index) => (
                <div key={index} className="flex items-center justify-between p-3 border-b border-gray-700">
                  <div className="flex items-center">
                    <img src={follow.photoURL || '/path/to/default/image.png'} alt={follow.name} className="w-10 h-10 rounded-full" />
                    <div className="ml-4">
                      <p className="text-white font-semibold">{follow.name}</p>
                      <p className="text-gray-400 text-sm">{follow.description || 'No description'}</p>
                    </div>
                  </div>
                  <button className="text-blue-500 border border-blue-500 rounded-full px-4 py-1">
                    Follow
                  </button>
                </div>
              ))
            ) : (
              <p className="text-gray-500 text-center">Not following anyone yet.</p>
            )
          )}
        </div>
      </div>
    </div>
  );
};

export default Followers;
