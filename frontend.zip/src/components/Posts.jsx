import { useState, useEffect } from 'react';
import { ArrowBigUp, ArrowBigDown, RefreshCcw } from 'lucide-react';
import { db } from '../Firebase/firebase'; 
import { collection, getDocs, doc, getDoc, updateDoc, increment, arrayUnion, query, where } from 'firebase/firestore'; // Import Firestore functions

const Posts = ({ userId }) => { 
    const [expandedTextIndex, setExpandedTextIndex] = useState(null);
    const [expandedImageIndex, setExpandedImageIndex] = useState(null);
    const [posts, setPosts] = useState([]); 
    const [users, setUsers] = useState({});
    console.log(userId) 

    useEffect(() => {
        const fetchPostsAndUsers = async () => {
            const postsCollection = collection(db, 'posts');
            const postsQuery = query(postsCollection, where('uid', '==', userId)); 
            const postsSnapshot = await getDocs(postsQuery);
            const postsList = postsSnapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));

            
            const userIds = Array.from(new Set(postsList.map(post => post.uid)));
            const usersData = {};
            for (const uid of userIds) {
                const userDoc = await getDoc(doc(db, 'users', uid));
                if (userDoc.exists()) {
                    usersData[uid] = userDoc.data();
                }
            }

            setPosts(postsList);
            setUsers(usersData);
        };

        fetchPostsAndUsers();
    }, [userId]); // Re-fetch posts whenever userId changes

    const handleTextToggle = (index) => {
        setExpandedTextIndex(expandedTextIndex === index ? null : index);
    };

    const handleImageToggle = (index) => {
        setExpandedImageIndex(expandedImageIndex === index ? null : index);
    };

    const handleUpvote = async (postId, currentVotes, upvotedBy) => {
        const currentUserId = 'user123'; // Replace with actual current user ID

        if (upvotedBy.includes(currentUserId)) {
            alert('You have already upvoted this post.');
            return;
        }

        try {
            const postRef = doc(db, 'posts', postId);
            await updateDoc(postRef, {
                votes: increment(1), // Increment votes by 1
                upvotedBy: arrayUnion(currentUserId) // Add the current user ID to the upvotedBy array
            });
            // Update local state for immediate UI feedback
            setPosts(prevPosts =>
                prevPosts.map(post =>
                    post.id === postId ? { ...post, votes: currentVotes + 1, upvotedBy: [...upvotedBy, currentUserId] } : post
                )
            );
        } catch (error) {
            console.error('Error upvoting post:', error);
        }
    };

    const handleShare = async (postId, currentShares, sharedBy) => {
        const currentUserId = 'user123'; // Replace with actual current user ID

        if (sharedBy.includes(currentUserId)) {
            alert('You have already shared this post.');
            return;
        }

        try {
            const postRef = doc(db, 'posts', postId);
            await updateDoc(postRef, {
                shares: increment(1), // Increment shares by 1
                sharedBy: arrayUnion(currentUserId) // Add the current user ID to the sharedBy array
            });
            // Update local state for immediate UI feedback
            setPosts(prevPosts =>
                prevPosts.map(post =>
                    post.id === postId ? { ...post, shares: currentShares + 1, sharedBy: [...sharedBy, currentUserId] } : post
                )
            );
        } catch (error) {
            console.error('Error sharing post:', error);
        }
    };

    return (
        <div>
            {posts.map((item, index) => {
                const userData = users[item.uid] || {}; // Fetch user data by uid
                return (
                    <div className="w-[100%] bg-[#262626] mt-2 pb-3" key={item.id}>
                        <div className="flex items-center p-3 w-full">
                            <img src={userData.photo || '/default-profile.png'} alt="" className="rounded-full w-10"/> {/* Add a default profile image if none is provided */}
                            <div className="p-4">
                                <h3 className="text-white text-sm font-semibold flex gap-2">{(userData.firstName+" "+ userData.lastName) || 'Anonymous'} • <p className="text-blue-500 cursor-pointer hover:underline">Follow</p></h3>
                            </div>
                        </div>
                        <div className="w-full px-3">
                            <p>
                                {expandedTextIndex === index || item.text.length <= 300 ? item.text : `${item.text.substring(0, 200)}...`}
                                {item.text.length > 200 && (
                                    <span 
                                        className="text-blue-500 cursor-pointer hover:underline" 
                                        onClick={() => handleTextToggle(index)}
                                    >
                                        {expandedTextIndex === index ? ' Show less' : ' Show more'}
                                    </span>
                                )}
                            </p>
                        </div>
                        <div className="w-full flex justify-center p-4 mt-1">
                            {item.imageUrl && (
                                <img 
                                    src={item.imageUrl} 
                                    alt="" 
                                    className={expandedImageIndex === index ? 'w-full' : 'w-[70%] h-[50%] cursor-pointer'} 
                                    onClick={() => handleImageToggle(index)} 
                                />
                            )}
                        </div>
                        <div className="w-full flex items-center mt-1 px-3 text-sm">
                            <p>{item.votes} upvotes • </p>
                            <p>{item.shares} shares </p>
                        </div>
                        <div className="w-full flex gap-3 items-center px-5 mt-1">
                            <div className="w-[24%] bg-[#313131] rounded-3xl flex justify-center items-center">
                                <div 
                                    className="flex pr-2 hover:bg-slate-600 cursor-pointer text-sm"
                                    onClick={() => handleUpvote(item.id, item.votes, item.upvotedBy || [])}
                                >
                                    <ArrowBigUp color="blue" />
                                    <p>upvote • {item.votes}</p>
                                </div>
                                <ArrowBigDown className="cursor-pointer hover:text-blue-400" />
                            </div>
                            <div 
                                className="flex justify-center items-center hover:text-slate-600 cursor-pointer px-2"
                                onClick={() => handleShare(item.id, item.shares, item.sharedBy || [])}
                            >
                                <RefreshCcw />
                                <p>{item.shares}</p>
                            </div>
                        </div>
                    </div>
                );
            })}
        </div>
    );
};

export default Posts;
