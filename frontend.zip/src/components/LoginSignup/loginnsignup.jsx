import { useState } from 'react';
import './style.css';
import facebook_img from "../../assets/pngwing 3.svg";
import google_img from "../../assets/pngwing 3.png";
import login_img from "../../assets/login_img.png";
import { CircleArrowLeft } from 'lucide-react';
import { auth, db, facebookProvider, googleProvider } from '../../Firebase/firebase';
import { createUserWithEmailAndPassword, signInWithEmailAndPassword,signInWithPopup } from 'firebase/auth';
import { setDoc, doc,serverTimestamp } from 'firebase/firestore';
import { ToastContainer, toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';

const LoginSignUp = () => {
  const [isSignUp, setIsSignUp] = useState(false);
  const [formInput, setFormInput] = useState({
    email: '',
    first_name: '',
    last_name: '',
    password: '',
    confirmPassword: '',
  });

  const handleSignUpClick = () => {
    setIsSignUp(true);
  };

  const handleLoginClick = () => {
    setIsSignUp(false);
  };

  const handleUserInput = (name, value) => {
    setFormInput({
      ...formInput,
      [name]: value,
    });
  };

  const signUp = async (event) => {
    event.preventDefault();
    if (formInput.password !== formInput.confirmPassword) {
      toast.error('Passwords do not match');
      return;
    }

    try {
      const userCredential = await createUserWithEmailAndPassword(auth, formInput.email, formInput.password);
      const user = userCredential.user;
      await setDoc(doc(db, "users", user.uid), {
        email: user.email,
        firstName: formInput.first_name,
        lastName: formInput.last_name,
        photo:"",
        employment:"",
        eduction:"",
        joinedAt:serverTimestamp(),
        adress:""
      });
      toast.success('Sign up successful! Redirecting...');
      window.location.replace("/home");
    } catch (error) {
      toast.error(error.message);
    }
  };

  const login = async (event) => {
    event.preventDefault();

    try {
      await signInWithEmailAndPassword(auth, formInput.email, formInput.password);
      toast.success('Login successful! Redirecting...');
      window.location.replace("/home");
    } catch (error) {
      toast.error(error.message);
    }
  };
  const googleSignup=()=>{
    signInWithPopup(auth,googleProvider)
    .then(async(result)=>{
      console.log(result.user);
      const user=result.user;
      await setDoc(doc(db,"users",user.uid),{
        email:user.email,
        firstName:result._tokenResponse.firstName,
        lastName:result._tokenResponse.lastName,
        photo:result._tokenResponse.photoUrl,
        employment:"",
        eduction:"",
        joinedAt:serverTimestamp(),
        adress:""
      })
      toast.success('Login successful! Redirecting...');
      window.location.replace("/home");

    })
    .catch((error)=>{
      console.log(error.message);
    })
  }
  const facebookLogin=()=>{
    signInWithPopup(auth,facebookProvider)
    .then(async(result)=>{
      console.log(result.user);
      const user=result.user;
      await setDoc(doc(db,"users",user.uid),{
        email:user.email,
        firstName:result._tokenResponse.firstName,
        lastName:result._tokenResponse.lastName,
        photo:result._tokenResponse.photoUrl,
        employment:"",
        eduction:"",
        joinedAt:serverTimestamp(),
        adress:""
      })
      toast.success('Login successful! Redirecting...');
      window.location.replace("/home");

    })
    .catch((error)=>{
      console.log(error.message);
    })
  }

  const handleForgetPassword = async (event) => {
    event.preventDefault();
    // Add Firebase's password reset logic here if needed.

  };

  return (
    <div className='body border-box'>
      <ToastContainer />
      <div className={`container-l ${isSignUp ? 'right-panel-active' : ''}`} id="main">
        <div className="sign-up relative">
          <form onSubmit={signUp}>
            <CircleArrowLeft className='absolute left-4 top-5 cursor-pointer' onClick={handleLoginClick} />
            <input
              type="email"
              name="email"
              placeholder="Email"
              value={formInput.email}
              onChange={(e) => handleUserInput('email', e.target.value)}
              required
            />
            <input
              type="text"
              name="first_name"
              placeholder="First Name"
              value={formInput.first_name}
              onChange={(e) => handleUserInput('first_name', e.target.value)}
              required
            />
            <input
              type="text"
              name="last_name"
              placeholder="Last Name"
              value={formInput.last_name}
              onChange={(e) => handleUserInput('last_name', e.target.value)}
              required
            />
            <input
              type="password"
              name="password"
              placeholder="Password"
              value={formInput.password}
              onChange={(e) => handleUserInput('password', e.target.value)}
              required
            />
            <input
              type="password"
              name="confirmPassword"
              placeholder="Re-Enter Password"
              value={formInput.confirmPassword}
              onChange={(e) => handleUserInput('confirmPassword', e.target.value)}
              required
            />
            <button type="submit">Sign Up</button>
          </form>
        </div>
        <div className="login">
          <form onSubmit={login}>
            <input
              type="email"
              name="email"
              placeholder="Email"
              value={formInput.email}
              onChange={(e) => handleUserInput('email', e.target.value)}
              required
            />
            <input
              type="password"
              name="password"
              placeholder="Password"
              value={formInput.password}
              onChange={(e) => handleUserInput('password', e.target.value)}
              required
            />
            <button type="submit">Login</button>
            <p className="forget-password" onClick={handleForgetPassword}>
              Forgot Password?
            </p>
            <div className="divider">
              <span className="or-text">OR</span>
            </div>
            <div className="social-media">
              <div className="social" onClick={facebookLogin}>
                <img src={facebook_img} alt="" />
              </div>
              <div className="social" onClick={googleSignup}>
                <img src={google_img} alt="" />
              </div>
            </div>
            <div className=''>
              <p>Don't Have an account? </p>
              <button id="sign-up " className='h-10 flex text-center p-0 m-0' onClick={handleSignUpClick}>
                Sign Up
              </button>
            </div>
          </form>
        </div>
        <div className="overlay-container">
          <div className="overlay">
            <div className="overlay-left">
              <img src={login_img} alt="" />
            </div>
            <div className="overlay-right">
              <img src={login_img} alt="" />
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default LoginSignUp;
