// BioEditor.js
import React, { useState } from 'react';
import { doc, updateDoc } from 'firebase/firestore';
import { db } from '../../Firebase/firebase';

const BioEditor = ({ userId, initialBio, onClose }) => {
  const [bio, setBio] = useState(initialBio);

  const handleSave = async () => {
    try {
      const userRef = doc(db, 'users', userId);
      await updateDoc(userRef, { bio });
      onClose();
    } catch (error) {
      console.error("Error updating bio: ", error);
    }
  };

  return (
    <div className='fixed  inset-0 bg-gray-800 bg-opacity-50 flex justify-center items-center'>
      <div className='bg-white p-5 rounded shadow-md'>
        <h2 className='text-xl font-bold mb-4'>Edit Bio</h2>
        <textarea
          className='w-full p-2 border text-black border-gray-300 rounded'
          rows="4"
          value={bio}
          onChange={(e) => setBio(e.target.value)}
        ></textarea>
        <div className='mt-4 flex justify-end'>
          <button
            className='mr-2 px-4 py-2 bg-red-500 text-white rounded'
            onClick={onClose}
          >
            Cancel
          </button>
          <button
            className='px-4 py-2 bg-blue-500 text-white rounded'
            onClick={handleSave}
          >
            Save
          </button>
        </div>
      </div>
    </div>
  );
};

export default BioEditor;
