import { Link, useLocation, useNavigate } from 'react-router-dom';
import { useState } from 'react';
import {
  House,
  Rss,
  Newspaper,
  HeartHandshake,
  Bell,
  Search,
  CircleUser,
  Pencil,
  Menu,
  X,
} from 'lucide-react';
import HoverDown from './smallComponents/HoverDown';
import CreatePost from './smallComponents/CreatePost';

const Navbar = () => {
  const location = useLocation();
  const [hoveredLink, setHoveredLink] = useState(null);
  const [create, setCreate] = useState(false);
  const [menuOpen, setMenuOpen] = useState(false);
  const navigate = useNavigate();

  const handleCreate = () => {
    setCreate(true);
  };

  const handleCloseCreate = () => {
    setCreate(false);
  };

  const toggleMenu = () => {
    setMenuOpen(!menuOpen);
  };

  // Function to close menu when a link is clicked (useful for mobile)
  const handleLinkClick = () => {
    setMenuOpen(false);
  };

  return (
    <nav className="w-screen bg-[#262626] fixed top-0 left-0 z-50 ">
      <div className="flex items-center justify-between lg:justify-evenly p-4 lg:p-4">
        {/* Logo */}
        <a href="/" className="text-3xl text-[#f52936] font-semibold">
          BLOGer
        </a>

        {/* Hamburger Menu Icon for Mobile */}
        <div className="lg:hidden">
          <button onClick={toggleMenu} aria-label="Toggle Menu">
            {menuOpen ? (
              <X color="white" size={30} />
            ) : (
              <Menu color="white" size={30} />
            )}
          </button>
        </div>

        {/* Navigation Links for Desktop */}
        <ul className="hidden lg:flex gap-7 h-full items-center">
          <li>
            <Link
              to="/"
              className="flex items-center px-3 py-2 rounded hover:bg-[#464748] relative"
              onMouseEnter={() => setHoveredLink('Home')}
              onMouseLeave={() => setHoveredLink(null)}
            >
              <House
                color={location.pathname === '/' ? '#f52936' : '#ecedee'}
                height={32}
                width={32}
                className="mr-2"
              />
          
              {location.pathname === '/' && (
                <hr className="absolute bottom-0 left-0 w-full bg-[#f52936] h-1" />
              )}
              {hoveredLink === 'Home' && <HoverDown name="Home" />}
            </Link>
          </li>

          <li>
            <Link
              to="/following"
              className="flex items-center px-3 py-2 rounded hover:bg-[#464748] relative"
              onMouseEnter={() => setHoveredLink('Following')}
              onMouseLeave={() => setHoveredLink(null)}
            >
              <Rss
                color={location.pathname === '/following' ? '#f52936' : '#ecedee'}
                height={32}
                width={32}
                className="mr-2"
              />
              {location.pathname === '/following' && (
                <hr className="absolute bottom-0 left-0 w-full bg-[#f52936] h-1" />
              )}
              {hoveredLink === 'Following' && <HoverDown name="Following" />}
            </Link>
          </li>

          <li>
            <Link
              to="/news"
              className="flex items-center px-3 py-2 rounded hover:bg-[#464748] relative"
              onMouseEnter={() => setHoveredLink('News')}
              onMouseLeave={() => setHoveredLink(null)}
            >
              <Newspaper
                color={location.pathname === '/news' ? '#f52936' : '#ecedee'}
                height={32}
                width={32}
                className="mr-2"
              />
              {location.pathname === '/news' && (
                <hr className="absolute bottom-0 left-0 w-full bg-[#f52936] h-1" />
              )}
              {hoveredLink === 'News' && <HoverDown name="News" />}
            </Link>
          </li>

          <li>
            <Link
              to="/health"
              className="flex items-center px-3 py-2 rounded hover:bg-[#464748] relative"
              onMouseEnter={() => setHoveredLink('Health')}
              onMouseLeave={() => setHoveredLink(null)}
            >
              <HeartHandshake
                color={location.pathname === '/health' ? '#f52936' : '#ecedee'}
                height={32}
                width={32}
                className="mr-2"
              />
              {location.pathname === '/health' && (
                <hr className="absolute bottom-0 left-0 w-full bg-[#f52936] h-1" />
              )}
              {hoveredLink === 'Health' && <HoverDown name="Health" />}
            </Link>
          </li>

          <li>
            <Link
              to="/notification"
              className="flex items-center px-3 py-2 rounded hover:bg-[#464748] relative"
              onMouseEnter={() => setHoveredLink('Notification')}
              onMouseLeave={() => setHoveredLink(null)}
            >
              <Bell
                color={location.pathname === '/notification' ? '#f52936' : '#ecedee'}
                height={32}
                width={32}
                className="mr-2"
              />
              {location.pathname === '/notification' && (
                <hr className="absolute bottom-0 left-0 w-full bg-[#f52936] h-1" />
              )}
              {hoveredLink === 'Notification' && <HoverDown name="Notification" />}
            </Link>
          </li>
        </ul>

        {/* Search Bar and Profile Options for Desktop */}
        <div className="hidden lg:flex items-center gap-5">
          {/* Search Bar */}
          <div className="flex p-2 bg-[#181818] hover:border-[1px] hover:border-white rounded">
            <Search color="#b6b8bb" />
            <input
              type="text"
              className="w-72 bg-[#181818] ml-2 border-none outline-none text-[#b6b8bb]"
              placeholder="Search"
            />
          </div>

          {/* Profile Icon */}
          <CircleUser
            color="white"
            size={32}
            onClick={() => navigate('/profile')}
            className="cursor-pointer"
          />

          {/* Create Post Button */}
          <div
            onClick={handleCreate}
            className="p-2 bg-[#f52936] w-40 gap-2 rounded-3xl flex justify-center items-center cursor-pointer"
          >
            <h2 className="text-[#ecedee] font-medium text-sm">Create Post</h2>
            <Pencil color="#ecedee" height={20} />
          </div>
        </div>
      </div>

      {/* Mobile Menu */}
      {menuOpen && (
        <div className="lg:hidden bg-[#262626] w-full">
          <ul className="flex flex-col items-start px-4 pt-2 pb-4 space-y-2 animate-slideDown">
            <li className="w-full">
              <Link
                to="/"
                className="flex items-center px-3 py-2 rounded hover:bg-[#464748] w-full"
                onClick={handleLinkClick}
              >
                <House
                  color={location.pathname === '/' ? '#f52936' : '#ecedee'}
                  height={24}
                  width={24}
                  className="mr-2"
                />
                <span className="text-white">Home</span>
              </Link>
            </li>
            <li className="w-full">
              <Link
                to="/following"
                className="flex items-center px-3 py-2 rounded hover:bg-[#464748] w-full"
                onClick={handleLinkClick}
              >
                <Rss
                  color={location.pathname === '/following' ? '#f52936' : '#ecedee'}
                  height={24}
                  width={24}
                  className="mr-2"
                />
                <span className="text-white">Followers</span>
              </Link>
            </li>
            <li className="w-full">
              <Link
                to="/news"
                className="flex items-center px-3 py-2 rounded hover:bg-[#464748] w-full"
                onClick={handleLinkClick}
              >
                <Newspaper
                  color={location.pathname === '/news' ? '#f52936' : '#ecedee'}
                  height={24}
                  width={24}
                  className="mr-2"
                />
                <span className="text-white">News</span>
              </Link>
            </li>
            <li className="w-full">
              <Link
                to="/health"
                className="flex items-center px-3 py-2 rounded hover:bg-[#464748] w-full"
                onClick={handleLinkClick}
              >
                <HeartHandshake
                  color={location.pathname === '/health' ? '#f52936' : '#ecedee'}
                  height={24}
                  width={24}
                  className="mr-2"
                />
                <span className="text-white">Health</span>
              </Link>
            </li>
            <li className="w-full">
              <Link
                to="/notification"
                className="flex items-center px-3 py-2 rounded hover:bg-[#464748] w-full"
                onClick={handleLinkClick}
              >
                <Bell
                  color={location.pathname === '/notification' ? '#f52936' : '#ecedee'}
                  height={24}
                  width={24}
                  className="mr-2"
                />
                <span className="text-white">Notifications</span>
              </Link>
            </li>
            {/* Search Bar for Mobile */}
            <li className="w-full">
              <div className="flex p-2 bg-[#181818] hover:border-[1px] hover:border-white rounded w-full">
                <Search color="#b6b8bb" />
                <input
                  type="text"
                  className="w-full bg-[#181818] ml-2 border-none outline-none text-[#b6b8bb]"
                  placeholder="Search"
                />
              </div>
            </li>
            {/* Profile and Create Post for Mobile */}
            <li className="w-full flex items-center space-x-4 mt-2">
              <CircleUser
                color="white"
                size={24}
                onClick={() => {
                  navigate('/profile');
                  handleLinkClick();
                }}
                className="cursor-pointer"
              />
              <div
                onClick={() => {
                  handleCreate();
                  handleLinkClick();
                }}
                className="p-2 bg-[#f52936] w-full gap-2 rounded-3xl flex justify-center items-center cursor-pointer"
              >
                <h2 className="text-[#ecedee] font-medium text-sm">Create Post</h2>
                <Pencil color="#ecedee" height={20} />
              </div>
            </li>
          </ul>
        </div>
      )}

      {/* Create Post Component */}
      <CreatePost selected={create} onClose={handleCloseCreate} />
    </nav>
  );
};

export default Navbar;
