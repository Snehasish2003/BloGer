import profile_1 from "../assets/profile_1.jpeg"
import blog_1 from "../assets/blog-1.jpg"
export const blogs = [
    {
        profile: profile_1 ,
        name: "Komal",
        occupation: "Student",
        time: "",
        title: "What are some unwritten social rules everyone should know?",
        text: "When somebody complains about their spouse, don't badmouth, just listen.Don't suggest a medicine to someone who is ill (unless you're a specialist).Don't look away during a conversation.When you realise your mistake, accept it don't go on arguing.Don't show your artistic nature on a borrowed book/notebook.somebody complains about their spouse, don't badmouth, just listen.Don't suggest a medicine to someone who is ill (unless you're a specialist).Don't look away during a conversation.When you realise your mistake, accept it don't go on arguing.Don't show your artistic nature on a borrowed book/notebook.",
        image: blog_1 ,
        votes: "20k",
        shares:300,

    },
    {
        profile:  profile_1 ,
        name: "Komal",
        occupation: "Student",
        time: "",
        title: "What are some unwritten social rules everyone should know?",
        text: "When somebody complains about their spouse, don't badmouth, just listen.Don't suggest a medicine to someone who is ill (unless you're a specialist).Don't look away during a conversation.When you realise your mistake, accept it don't go on arguing.Don't show your artistic nature on a borrowed book/notebook.somebody complains about their spouse, don't badmouth, just listen.Don't suggest a medicine to someone who is ill (unless you're a specialist).Don't look away during a conversation.When you realise your mistake, accept it don't go on arguing.Don't show your artistic nature on a borrowed book/notebook.",
        image:  blog_1 ,
        votes: "20",
        shares:300,

    }
]